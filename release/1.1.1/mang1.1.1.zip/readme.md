﻿mang-1.1.1[20151012].jar
# 修改
 * 前一版本v1.1
 * SpringUtil 添加去掉字符串数字的方法cleanNumber()
