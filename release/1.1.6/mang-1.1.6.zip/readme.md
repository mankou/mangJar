﻿# V1.1.6
* + StringUtil.splitToArray()方法 将字符串转换成字符串数组
# V1.1.5
* + NumberUtil.isNumber() 方法 判断字符串是否由数字组成
# V1.1.4
* + TimeUtil.computeTimeInterval() 增加语言设置 可设置中文、英文
* + StringUtil.select() 选择字符串工具类
# V1.1.3
* + FileUtil增加processEndSeparator方法
* * FileUtil修改注释

# V1.1.2
 * +FileUtil 添加了几个处理文件的方法
# V1.1.1
 * +SpringUtil 添加去掉字符串数字的方法cleanNumber()
